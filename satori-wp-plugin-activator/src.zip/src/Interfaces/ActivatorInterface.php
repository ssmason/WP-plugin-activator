<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

namespace SatoriDigital\PluginActivator\Interfaces;

/**
 * Activations Interface
 *
 * @category Interface
 * @package  SatoriDigital\Activate\Interfaces
 */
class ActivationInterface {

	/**
	 * Activate plugins for the current theme.
	 *
	 * @return void
	 */
	public function activate_theme_plugins(): void;

	/**
	 * Activate plugins for the network.
	 *
	 * @return void
	 */
	public function activate_network_plugins(): void;

	/**
	 * Activate plugins for the site.
	 *
	 * @return void
	 */
	public function activate_site_plugins(): void;

	/**
	 * Deactivate plugins for the current theme.
	 *
	 * @return void
	 */
	public function deactivate_theme_plugins(): void;

	/**
	 * Deactivate plugins for the network.
	 *
	 * @return void
	 */
	public function deactivate_network_plugins(): void;

	/**
	 * Deactivate plugins for the site.
	 *
	 * @return void
	 */
	public function deactivate_site_plugins(): void;

}
