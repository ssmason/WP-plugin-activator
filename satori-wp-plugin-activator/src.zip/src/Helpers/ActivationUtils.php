<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

namespace SatoriDigital\PluginActivator\Helpers;

/**
 * Activate Class
 *
 * Class to load plugins either at network or site level
 */
class ActivationUtils {
 
	/**
	 * Array of plugin keys required to activate plugins at specific points ie theme/settings/filters
	 *
	 * @var array
	 */
	private $keys;
 
	/**
	 * Plugin constructor.
	 */
	public function __construct() {
	}
 
    /**
	 * Ensure required WordPress plugin functions are loaded.
	 * 
	 * @return void
	*/
	private function ensure_wp_plugin_functions(): void {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	}
	/**
	 * Activate an array of plugins by their basenames using WordPress core functions.
	 * Logs any activation errors.
	 * 
	 * @param array $plugins Array of plugin basenames (e.g. 'query-monitor/query-monitor.php').
	 * @return void
	*/
	private function activate_plugins( array $plugins ): void {
		$this->ensure_wp_plugin_functions();

		foreach ( $plugins as $basename ) {
			if ( ! is_plugin_active( $basename ) ) {
				$result = activate_plugin( $basename );

				if ( is_wp_error( $result ) ) {
					error_log(
						sprintf(
							'[PluginActivator] Failed to activate plugin "%s": %s',
							$basename,
							$result->get_error_message()
						)
					);
				} else {
					error_log(
						sprintf(
							'[PluginActivator] Activated plugin "%s".',
							$basename
						)
					);
				}
			}
		}
	}

	/**
	 * Evaluate the state of all plugins listed in the theme config.
	 * Checks if plugins exist, are active, and meet version requirements.
	 * Logs missing plugins and version mismatches.
	 * 
	 * @return array Evaluation results including to_activate, missing, version_issues, and a detailed report.
	*/
	private function evaluate_theme_plugins(): array {
		$this->ensure_wp_plugin_functions();

		$plan = [
			'to_activate'     => [],
			'missing'         => [],
			'version_issues'  => [],
			'report'          => [],
		];

		foreach ( $this->keys['plugins'] as $p ) {
			$file      = $p['file'];
			$abs       = WP_PLUGIN_DIR . '/' . $file;
			$basename  = plugin_basename( $abs );
			$exists    = file_exists( $abs );
			$active    = $exists ? is_plugin_active( $basename ) : false;
			$installed = $exists ? $this->get_plugin_version( $abs ) : null;
			$ok        = $this->satisfies_version( $installed, $p['version'] ?? null );

			if ( ! $exists ) {
				$plan['missing'][] = $file;

				error_log(
					sprintf(
						'[PluginActivator] Missing plugin file: %s (declared in theme config)',
						$file
					)
				);

			} elseif ( ! $active ) {
				$plan['to_activate'][] = $basename;
			}

			if ( $exists && ! $ok ) {
				$plan['version_issues'][ $basename ] = [ $installed, $p['version'] ?? null ];

				error_log(
					sprintf(
						'[PluginActivator] Version mismatch for %s. Installed: %s, Required: %s',
						$basename,
						$installed ?? 'unknown',
						$p['version'] ?? 'unspecified'
					)
				);
			}

			$plan['report'][] = [
				'file'              => $file,
				'basename'          => $basename,
				'exists'            => $exists,
				'active'            => $active,
				'installed_version' => $installed,
				'version_ok'        => $ok,
				'required'          => (bool) ( $p['required'] ?? false ),
				'order'             => (int) ( $p['order'] ?? 10 ),
			];
		}

		return $plan;
	}
 
    /**
	 * Check if an installed version satisfies a version constraint.
	 * Supports operators like >=, <=, ==, <, >, =.
	 * 
	 * @param string|null $installed Installed plugin version.
	 * @param string|null $constraint Version constraint (e.g. ">=3.14.0").
	 * @return bool True if the version satisfies the constraint.
	*/
	private function satisfies_version( ?string $installed, ?string $constraint ): bool {
		if ( empty( $constraint ) || empty( $installed ) ) {
			return true;
		}
		if ( ! preg_match( '/^(<=|>=|==|=|<|>)\s*([0-9A-Za-z\.\-\+]+)$/', $constraint, $m ) ) {
			return true;
		}
		$op  = $m[1] === '=' ? '==' : $m[1];
		$ver = $m[2];
		return version_compare( $installed, $ver, $op );
	}

    /**
	 * Get the version of a plugin from its file header.
	 * 
	 * @param string $abs Absolute path to the plugin file.
	 * @return string|null Plugin version or null if not found.
	*/
	private function get_plugin_version( string $abs ): ?string {
		if ( ! file_exists( $abs ) ) {
			return null;
		}
		$headers = get_file_data( $abs, [ 'Version' => 'Version' ] );
		return ! empty( $headers['Version'] ) ? $headers['Version'] : null;
	}
}
