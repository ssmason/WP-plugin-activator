<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

namespace SatoriDigital\PluginActivator\Helpers;

/**
 * Activate Class
 *
 * Class to load plugins either at network or site level
 */
class FilterController {
 
	/**
	 * Array of plugin keys required to activate plugins at specific points ie theme/settings/filters
	 *
	 * @var array
	 */
	private $keys;
 
	/**
	 * Plugin constructor.
	 */
	public function __construct() {
        $this->set_keys( get_option( 'stylesheet', '' ) );
	}
 
	/**
	 * Set the theme keys, plugins, filters & settings
	 * 
	 * @param String $theme Name of the theme for which config is required.
	 */
	public function set_keys( string $theme ): void {

		$config = $this->get_json_config( $theme );
		if ( ! is_array( $config ) ) {
			error_log( sprintf(
				'[PluginActivator] Invalid JSON config for theme "%s". Falling back to empty config.',
				$theme
			) );
			$config = [];
		}

		// Ensure top-level keys exist
		$config = array_merge(
			[
				'plugins'   => [],
				'filtered'  => [],
				'settings'  => [],
				'deactivate'=> [],
				'groups'    => []
			],
			$config
		);

		// Normalize plugins: convert string entries to structured arrays with defaults
		$normalized_plugins = [];
		if ( is_array( $config['plugins'] ) ) {
			foreach ( $config['plugins'] as $plugin ) {
				if ( is_string( $plugin ) ) {
					$normalized_plugins[] = [
						'file'     => $plugin,
						'required' => false,
						'version'  => null,
						'order'    => 10
					];
				} elseif ( is_array( $plugin ) && ! empty( $plugin['file'] ) ) {
					$normalized_plugins[] = array_merge(
						[
							'required' => false,
							'version'  => null,
							'order'    => 10
						],
						$plugin
					);
				}
				// Invalid plugin entries are silently skipped
			}
		}

		$config['plugins'] = $normalized_plugins;
		$this->keys = $config;
	}

	/**
	 * Get theme array keys
	*/
	public function get_keys():array {
		return $this->keys;
	} 
}
