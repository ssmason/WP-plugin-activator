<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

use SatoriDigital\PluginActivator\Helpers\ConfigLoader;
use SatoriDigital\PluginActivator\Helpers\ActivationUtils;

namespace SatoriDigital\PluginActivator\Activators;

/**
 * Activate Class
 *
 * Class to load plugins either at network or site level
 */
class FilterActivator {
 
    /**
	 * Array of plugin keys required to activate plugins at specific points ie theme/settings/filters
	 *
	 * @var array
	*/
	private $keys;
 
	/**
	 * Plugin constructor.
	 */
	public function __construct() {
	}

	/**
	 * Activate plugins on specific WordPress hooks based on the "filtered" configuration.
	 * Each entry specifies a hook, optional priority, and plugins to activate when that hook fires.
	 * Logs any misconfigured entries for easier debugging.
	 * 
	 * @return void
	*/
	private function filter_activation(): void {
		if ( empty( $this->get_keys()['filtered'] ) || ! is_array( $this->get_keys()['filtered'] ) ) {
			return;
		}

		foreach ( $this->get_keys()['filtered'] as $entry ) {
			$hook     = $entry['hook']    ?? null;
			$plugins  = $entry['plugins'] ?? [];
			$priority = isset( $entry['priority'] ) ? (int) $entry['priority'] : 10;

			// Basic validation
			if ( empty( $hook ) || empty( $plugins ) || ! is_array( $plugins ) ) {
				error_log(
					sprintf(
						'[PluginActivator] Invalid filtered activation entry detected: %s',
						wp_json_encode( $entry )
					)
				);
				continue;
			}

			add_action(
				$hook,
				function() use ( $plugins, $hook ) {
					$this->activate_plugins( $plugins );

					error_log(
						sprintf(
							'[PluginActivator] Filtered activation triggered on hook "%s" for plugins: %s',
							$hook,
							implode( ', ', $plugins )
						)
					);
				},
				$priority
			);
		}
	}

}
