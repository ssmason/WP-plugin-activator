<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

namespace SatoriDigital\PluginActivator\Activators;

use SatoriDigital\PluginActivator\Helpers\ConfigLoader;
use SatoriDigital\PluginActivator\Helpers\ActivationUtils;

/**
 * Activate Class
 *
 * Class to load plugins either at network or site level
 */
class PluginActivator {
 
	/**
	 * Array of plugin keys required to activate plugins at specific points ie theme/settings/filters
	 *
	 * @var array
	 */
	private $keys;
 
	/**
	 * Plugin constructor.
	 */
	public function __construct() {
	}
 
	/**
	 * Activate plugins that are specific to the current theme.
	 * Evaluates plugin state first, then activates as needed.
	 * Logs any missing plugins or version issues.
	 * 
	 * @return void
	*/
	private function theme_activation(): void {

		if ( isset( $this->get_keys()['plugins'] ) && is_array( $this->get_keys()['plugins'] ) ) {
			$plan = $this->evaluate_theme_plugins();

			// Activate any plugins that are not currently active
			if ( ! empty( $plan['to_activate'] ) ) {
				$this->activate_plugins( $plan['to_activate'] );
			}

			// Log missing plugins
			if ( ! empty( $plan['missing'] ) ) {
				foreach ( $plan['missing'] as $missing_plugin ) {
					error_log(
						sprintf(
							'[PluginActivator] Theme activation: Missing plugin "%s" — cannot activate.',
							$missing_plugin
						)
					);
				}
			}

			// Log version issues
			if ( ! empty( $plan['version_issues'] ) ) {
				foreach ( $plan['version_issues'] as $basename => $versions ) {
					list( $installed, $required ) = $versions;
					error_log(
						sprintf(
							'[PluginActivator] Theme activation: Version issue for "%s". Installed: %s, Required: %s',
							$basename,
							$installed ?? 'unknown',
							$required ?? 'unspecified'
						)
					);
				}
			}
		}
	}

	

}
