<?php
/**
 * Satori Digital Plugin Activator
 *
 * @category Plugin_Loader
 * @package  SatoriDigital\Activate
 */

declare( strict_types=1 );

namespace SatoriDigital\PluginActivator\Controllers;

use SatoriDigital\PluginActivator\Activators\PluginActivator;
use SatoriDigital\PluginActivator\Activators\SettingsActivator;
use SatoriDigital\PluginActivator\Activators\FilterController;


/**
 * Activate Class
 *
 * Class to load plugins either at network or site level
 */
class ActivationController.php {
 
	/**
	 * Array of plugin keys required to activate plugins at specific points ie theme/settings/filters
	 *
	 * @var array
	 */
	private $keys;
 
	/**
	 * Plugin constructor.
	 */
	public function __construct() { 
	}
 
	
 
	/**
	 * Main function runninng activation controllers
	*/
	public function run():bool { 
 
		//$this->network_activation(); 
		$this->theme_activation();
		$this->filter_activation();
		$this->settings_activation();
		return true;
	}
 
	

	

	
	

	
	

}
